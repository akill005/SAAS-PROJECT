## Basic

<code src="../example/basic.tsx"></code>

## Disabled

<code src="../example/disabled.tsx"></code>

## Disabled Alpha

<code src="../example/disabledAlpha.tsx"></code>

## Custom Render

<code src="../example/panelRender.tsx"></code>

## Work with Trigger

<code src="../example/trigger.tsx"></code>

## Color change completed

<code src="../example/changeComplete.tsx"></code>

## Color Block

<code src="../example/block.tsx"></code>

## Components

<code src="../example/components.tsx"></code>
