import ColorPicker from '@rc-component/color-picker';
import React from 'react';
import '../../assets/index.less';

export default () => {
  return <ColorPicker disabledAlpha />;
};
